<?php 	

	define('W_BTN_SM' , 'btn-sm');